 
import './App.css';
import'./components/MovieApp.js';
import MovieApp from './components/MovieApp.js';
function App() {
  return (
    <div>
    <MovieApp></MovieApp>
    </div>
  );
}

export default App;
